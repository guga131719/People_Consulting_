﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;

public class Autenticacoes : System.Web.Services.WebService
{

  [WebMethod]
  public int verificaUsuario(string login, string senha)
  {
    int idUsuario = 0;
    SqlConnection cn = new SqlConnection();
    cn.ConnectionString = @"Data Source=GUGA-PC\SQLEXPRESS;Initial Catalog=Cursos;Integrated Security=True";
    cn.Open();

    string q = "SELECT Id_usuario FROM Usuarios ";
    q += "WHERE Login = '" + login + "'";
    q += " AND Senha = '" + senha + "'";
    SqlCommand cd = new SqlCommand();
    cd.CommandText = q;
    cd.Connection = cn;
    SqlDataReader dr = cd.ExecuteReader();
    if (dr.Read())
      idUsuario = Convert.ToInt32(dr["Id_usuario"].ToString());
    dr.Close();
    cn.Close();

    return idUsuario;

  }
}